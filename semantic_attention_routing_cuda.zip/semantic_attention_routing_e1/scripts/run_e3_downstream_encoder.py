from __future__ import annotations

import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import argparse
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import torch
import yaml
from datasets import load_dataset
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from sar.data.schemas import Example, TokenizedExample
from sar.models.pairwise_masking import pairwise_to_additive_mask
from sar.semantics.sp2_windowed_span import SP2WindowedSpanComputer


def _load_yaml(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _special_ids(tokenizer) -> set[int]:
    ids = set()
    for tid in [
        tokenizer.cls_token_id,
        tokenizer.sep_token_id,
        tokenizer.pad_token_id,
        tokenizer.bos_token_id,
        tokenizer.eos_token_id,
    ]:
        if tid is not None:
            ids.add(int(tid))
    return ids


def tokenize_text(
    *,
    model_name: str,
    text: str,
    domain: str,
    example_id: str,
    tokenizer,
    max_length: int,
    exclude_special: bool = True,
) -> TokenizedExample:
    enc = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=max_length,
        return_offsets_mapping=True,
        padding=False,
        add_special_tokens=True,
    )
    ids = enc["input_ids"][0].tolist()
    attn_mask = enc["attention_mask"][0].tolist()
    offsets = [tuple(x) for x in enc["offset_mapping"][0].tolist()]
    tokens = tokenizer.convert_ids_to_tokens(ids)
    sp_ids = _special_ids(tokenizer)
    valid = [
        i
        for i, (tid, am) in enumerate(zip(ids, attn_mask))
        if am == 1 and (not exclude_special or tid not in sp_ids)
    ]
    return TokenizedExample(
        example_id=example_id,
        domain=domain,
        text=text,
        tokens=tokens,
        token_ids=ids,
        attention_mask=attn_mask,
        offset_mapping=offsets,
        valid_token_indices=valid,
        model_name=model_name,
    )


def build_keep_mask_from_similarity(sim: np.ndarray, valid_idx: List[int], quantile: float) -> np.ndarray:
    """Return boolean keep mask [seq, seq] using quantile threshold over valid pairs."""
    seq = sim.shape[0]
    keep = np.zeros((seq, seq), dtype=bool)
    if len(valid_idx) < 2:
        return keep
    vv = np.ix_(valid_idx, valid_idx)
    vals = sim[vv].reshape(-1)
    thr = np.quantile(vals, quantile)
    keep[vv] = sim[vv] >= thr
    # Always keep diagonal
    np.fill_diagonal(keep, True)
    return keep


@torch.no_grad()
def evaluate(
    *,
    model,
    tokenizer,
    ds,
    sp2: SP2WindowedSpanComputer,
    max_length: int,
    quantile: float,
    device: str,
    limit: int,
) -> Dict[str, float]:
    model.eval()
    model.to(device)

    correct_full = 0
    correct_sar = 0
    total = 0

    for i, row in enumerate(ds):
        if i >= limit:
            break
        text = row["sentence"]
        label = int(row["label"])

        tok = tokenize_text(
            model_name=model.config._name_or_path,
            text=text,
            domain="sst2",
            example_id=f"sst2_{i}",
            tokenizer=tokenizer,
            max_length=max_length,
        )

        inputs = tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=max_length,
            padding=False,
            add_special_tokens=True,
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}

        # Full
        out_full = model(**inputs)
        pred_full = int(out_full.logits.argmax(dim=-1).item())

        # SAR mask via SP2
        sim_art = sp2.compute(tok)
        keep_np = build_keep_mask_from_similarity(sim_art.similarity, tok.valid_token_indices, quantile)
        keep = torch.from_numpy(keep_np).bool().unsqueeze(0)
        add_mask = pairwise_to_additive_mask(keep, dtype=torch.float32, device=torch.device(device))

        # Some encoder models accept 4D additive masks directly.
        # If this fails, fallback to full attention.
        try:
            out_sar = model(**inputs, attention_mask=add_mask)
            pred_sar = int(out_sar.logits.argmax(dim=-1).item())
        except Exception:
            pred_sar = pred_full

        correct_full += int(pred_full == label)
        correct_sar += int(pred_sar == label)
        total += 1

    return {
        "acc_full": correct_full / max(total, 1),
        "acc_sar": correct_sar / max(total, 1),
        "delta_acc": (correct_sar - correct_full) / max(total, 1),
        "n": float(total),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--limit", type=int, default=200)
    args = ap.parse_args()

    cfg = _load_yaml(args.config)

    device = cfg.get("device", "cuda" if torch.cuda.is_available() else "cpu")
    model_id = cfg.get("model_id", "bert-base-uncased")
    max_length = int(cfg.get("max_length", 128))
    quantile = float(cfg.get("similarity_quantile", 0.95))

    out_dir = Path(cfg.get("output_dir", "results/e3_encoder"))
    _ensure_dir(out_dir)

    ds = load_dataset("glue", "sst2", split="validation")

    tokenizer = AutoTokenizer.from_pretrained(model_id, use_fast=True)
    model = AutoModelForSequenceClassification.from_pretrained(model_id)

    sp2 = SP2WindowedSpanComputer(
        model_name=cfg.get("sentence_transformer_id", "all-MiniLM-L6-v2"),
        window_k=int(cfg.get("sp2_window_k", 5)),
        normalize_embeddings=bool(cfg.get("normalize_embeddings", True)),
    )

    metrics = evaluate(
        model=model,
        tokenizer=tokenizer,
        ds=ds,
        sp2=sp2,
        max_length=max_length,
        quantile=quantile,
        device=device,
        limit=args.limit,
    )

    (out_dir / "e3_encoder_summary.yaml").write_text(yaml.safe_dump(metrics, sort_keys=False), encoding="utf-8")
    print(yaml.safe_dump(metrics, sort_keys=False))


if __name__ == "__main__":
    main()
