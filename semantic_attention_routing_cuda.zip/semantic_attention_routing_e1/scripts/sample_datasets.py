"""
Generate domain-stratified dataset samples for SAR experiments.

Domain → HuggingFace dataset mapping (parquet/arrow based; no script loaders):
  dialogue   → AlekseyKorshuk/persona-chat
  prose      → wikimedia/wikipedia (20231101.en)
  code       → codeparrot/github-code (streaming)
  structured → rajpurkar/squad

Fallbacks: If any HF dataset fails, the script tries alternatives.

Each domain: 200 examples, 3 sequence length buckets (128/256/512 tokens).
Output: data/domain_samples.jsonl  +  results/manifests/domain_samples.jsonl
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from transformers import AutoTokenizer
from datasets import load_dataset
from sar.config import load_e1_config


# ── Domain source definitions ──────────────────────────────────────
# IMPORTANT: Hugging Face `datasets>=4` rejects many legacy script-based datasets.
# Prefer parquet/arrow sources.

DOMAIN_SOURCES: Dict[str, List[Dict[str, Any]]] = {
    "dialogue": [
        {
            "path": "AlekseyKorshuk/persona-chat",
            "name": None,
            "split": "train",
            "text_field": "utterances",  # nested, handled below
            "flatten_turns": False,
            "streaming": False,
            "special_parser": "persona_chat",
        },
        {   # Fallback: empathetic dialogues
            "path": "facebook/empathetic_dialogues",
            "name": None,
            "split": "train",
            "text_field": "utterance",
            "flatten_turns": False,
            "streaming": False,
            "concat_consecutive": 6,
        },
    ],
    "prose": [
        {
            "path": "wikimedia/wikipedia",
            "name": "20231101.en",
            "split": "train",
            "text_field": "text",
            "flatten_turns": False,
            "streaming": False,
            "truncate_chars": 1000,
        },
        {   # Fallback: wikitext
            "path": "Salesforce/wikitext",
            "name": "wikitext-103-v1",
            "split": "train",
            "text_field": "text",
            "flatten_turns": False,
            "streaming": False,
            "concat_consecutive": 3,
        },
    ],
    "code": [
        {
            "path": "codeparrot/github-code",
            "name": None,
            "split": "train",
            "text_field": "code",
            "flatten_turns": False,
            "streaming": True,
        },
        {   # Fallback: the-stack-smol
            "path": "bigcode/the-stack-smol",
            "name": "data/python",
            "split": "train",
            "text_field": "content",
            "flatten_turns": False,
            "streaming": True,
        },
    ],
    "structured": [
        {
            "path": "rajpurkar/squad",
            "name": None,
            "split": "train",
            "text_field": "context",
            "flatten_turns": False,
            "streaming": False,
        },
        {   # Fallback: squad_v2
            "path": "rajpurkar/squad_v2",
            "name": None,
            "split": "train",
            "text_field": "context",
            "flatten_turns": False,
            "streaming": False,
        },
    ],
}

BUCKET_RANGES: Dict[int, Tuple[int, int]] = {
    128: (64, 160),
    256: (160, 384),
    512: (384, 600),
}

SAMPLES_PER_DOMAIN = 200
SAMPLES_PER_BUCKET = SAMPLES_PER_DOMAIN // len(BUCKET_RANGES)  # ~66 each
MAX_STREAM_SCAN = 50_000  # how many raw examples to scan per domain


def stable_id(domain: str, text: str) -> str:
    h = hashlib.sha256(f"{domain}:{text[:512]}".encode()).hexdigest()[:12]
    return f"{domain}_{h}"


def _try_load_dataset(source_cfg: Dict[str, Any]):
    """Try loading a single dataset config. Returns dataset iterator or None."""
    kwargs = {"path": source_cfg["path"], "split": source_cfg["split"]}
    if source_cfg.get("name"):
        kwargs["name"] = source_cfg["name"]
    if source_cfg.get("streaming", False):
        kwargs["streaming"] = True
    try:
        ds = load_dataset(**kwargs)
        return ds
    except Exception:
        return None


def _persona_chat_to_text(row: Dict[str, Any]) -> str:
    """Parse persona-chat rows into a single text string."""
    utt = row.get("utterances")
    if isinstance(utt, dict):
        hist = utt.get("history")
        if isinstance(hist, list):
            return " ".join(str(x).strip() for x in hist if str(x).strip())
    if isinstance(utt, list):
        parts: List[str] = []
        for item in utt:
            if isinstance(item, dict) and isinstance(item.get("history"), list):
                parts.extend(str(x).strip() for x in item["history"] if str(x).strip())
        if parts:
            return " ".join(parts)
    return ""


def extract_texts(domain: str, source_cfgs: List[Dict[str, Any]]) -> List[str]:
    """Try each source config in order until one works."""
    for idx, source_cfg in enumerate(source_cfgs):
        label = source_cfg["path"]
        if source_cfg.get("name"):
            label += f"/{source_cfg['name']}"
        print(f"  Trying source {idx+1}/{len(source_cfgs)}: {label}...")

        ds = _try_load_dataset(source_cfg)
        if ds is None:
            print(f"    ✗ Failed to load, trying next...")
            continue

        texts: List[str] = []
        field = source_cfg["text_field"]
        flatten = source_cfg.get("flatten_turns", False)
        concat_n = source_cfg.get("concat_consecutive", 0)
        truncate_chars = int(source_cfg.get("truncate_chars", 0) or 0)
        special_parser = source_cfg.get("special_parser")
        limit = MAX_STREAM_SCAN

        buffer: List[str] = []

        for i, row in enumerate(ds):
            if i >= limit:
                break
            if special_parser == "persona_chat":
                raw = _persona_chat_to_text(row)
            else:
                raw = row.get(field, "")

            # Handle list fields (dialog turns)
            if flatten and isinstance(raw, list):
                raw = " ".join(str(t).strip() for t in raw if str(t).strip())
            elif isinstance(raw, list):
                raw = " ".join(str(t) for t in raw)

            if not isinstance(raw, str):
                raw = str(raw)

            raw = raw.strip()
            if not raw or len(raw) < 20:
                continue

            if truncate_chars and len(raw) > truncate_chars:
                raw = raw[:truncate_chars]

            if concat_n > 0:
                buffer.append(raw)
                if len(buffer) >= concat_n:
                    combined = " ".join(buffer)
                    if len(combined) > 50:
                        texts.append(combined)
                    buffer = []
            else:
                if len(raw) > 50:
                    texts.append(raw)

        # Flush remaining buffer
        if buffer and concat_n > 0:
            combined = " ".join(buffer)
            if len(combined) > 50:
                texts.append(combined)

        if texts:
            # Deduplicate (some datasets have repeated contexts, e.g. squad)
            texts = list(dict.fromkeys(texts))
            print(f"    ✓ {len(texts)} unique texts extracted")
            return texts
        else:
            print(f"    ✗ No usable texts, trying next...")

    print(f"  WARNING: All sources failed for domain={domain}")
    return []


def bucket_and_sample(
    texts: List[str],
    domain: str,
    tokenizer: Any,
    samples_per_bucket: int = SAMPLES_PER_BUCKET,
) -> List[Dict[str, Any]]:
    """Assign texts to length buckets and sample evenly."""
    import random
    random.seed(42)

    buckets: Dict[int, List[str]] = {b: [] for b in BUCKET_RANGES}

    for text in texts:
        n_tokens = len(tokenizer.encode(text, truncation=False, add_special_tokens=True))
        for bkt, (lo, hi) in BUCKET_RANGES.items():
            if lo <= n_tokens < hi:
                buckets[bkt].append(text)
                break

    samples: List[Dict[str, Any]] = []
    for bkt in sorted(BUCKET_RANGES.keys()):
        pool = buckets[bkt]
        if not pool:
            print(f"    WARNING: bucket {bkt} empty for domain={domain}")
            continue
        chosen = random.sample(pool, min(samples_per_bucket, len(pool)))
        for text in chosen:
            samples.append({
                "example_id": stable_id(domain, text),
                "domain": domain,
                "text": text,
                "length_bucket": bkt,
            })

    print(f"    → {len(samples)} samples across buckets "
          f"({', '.join(f'{b}:{len(buckets[b])}' for b in sorted(buckets))})")
    return samples


def main():
    parser = argparse.ArgumentParser(description="Generate SAR domain samples")
    parser.add_argument("--config", required=True, help="Experiment YAML config path")
    parser.add_argument("--output_jsonl", default=None,
                        help="Override output JSONL path (default: data/domain_samples.jsonl)")
    parser.add_argument("--samples_per_domain", type=int, default=SAMPLES_PER_DOMAIN)
    parser.add_argument("--domains", nargs="*", default=None,
                        help="Subset of domains to process (default: all)")
    args = parser.parse_args()

    cfg = load_e1_config(args.config)

    # Use the sentence encoder's base model tokenizer for length estimation
    # We pick the first model in config for tokenization
    tok_name = cfg.models[0].hf_id if cfg.models else "bert-base-uncased"
    print(f"Using tokenizer: {tok_name}")
    tokenizer = AutoTokenizer.from_pretrained(tok_name, use_fast=True)

    domains = args.domains or list(DOMAIN_SOURCES.keys())
    spb = args.samples_per_domain // len(BUCKET_RANGES)

    all_samples: List[Dict[str, Any]] = []

    for domain in domains:
        if domain not in DOMAIN_SOURCES:
            print(f"WARNING: unknown domain '{domain}', skipping")
            continue
        print(f"\n[Domain] {domain}")
        source_cfgs = DOMAIN_SOURCES[domain]
        texts = extract_texts(domain, source_cfgs)
        samples = bucket_and_sample(texts, domain, tokenizer, samples_per_bucket=spb)
        all_samples.extend(samples)

    # Write output
    root = Path(PROJECT_ROOT)
    out_data = Path(args.output_jsonl) if args.output_jsonl else root / "data" / "domain_samples.jsonl"
    out_data.parent.mkdir(parents=True, exist_ok=True)
    with out_data.open("w", encoding="utf-8") as f:
        for s in all_samples:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(all_samples)} samples → {out_data}")

    # Also write manifest
    manifest_dir = root / "results" / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = manifest_dir / "domain_samples.jsonl"
    with manifest_path.open("w", encoding="utf-8") as f:
        for s in all_samples:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")
    print(f"Manifest copy → {manifest_path}")

    # Summary
    from collections import Counter
    domain_counts = Counter(s["domain"] for s in all_samples)
    bucket_counts = Counter(s["length_bucket"] for s in all_samples)
    print(f"\nSummary:")
    print(f"  Domains: {dict(domain_counts)}")
    print(f"  Buckets: {dict(bucket_counts)}")
    print(f"  Total:   {len(all_samples)}")


if __name__ == "__main__":
    main()
