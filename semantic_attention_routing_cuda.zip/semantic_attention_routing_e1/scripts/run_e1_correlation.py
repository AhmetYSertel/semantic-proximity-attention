from __future__ import annotations
import os, sys
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
import argparse
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
import pandas as pd
import torch
from tqdm import tqdm
from sar.config import load_e1_config
from sar.metrics.correlation import evaluate_correlation, make_valid_pair_mask
from sar.models.attention_extractor import AttentionExtractor
from sar.semantics.controls import build_token_frequency_dict, compute_controls
from sar.semantics.sp1_raw_token import SP1RawTokenComputer
from sar.semantics.sp2_windowed_span import SP2WindowedSpanComputer
from sar.utils.device import resolve_device
from sar.utils.io import load_jsonl_examples, write_json
from sar.utils.seeds import set_global_seed

def ensure_dirs(base: Path) -> Dict[str, Path]:
    raw = base / "raw" / "example_metrics"; agg = base / "aggregates"
    raw.mkdir(parents=True, exist_ok=True); agg.mkdir(parents=True, exist_ok=True)
    return {"raw": raw, "agg": agg}

def get_sp_computers(cfg: Dict[str, Any]) -> Dict[str, Any]:
    se = cfg["sentence_encoder"]; out = {}
    st_device = se.get("device", "cpu")
    for sp in cfg["sp_types"]:
        if sp == "sp1_raw_token":
            out[sp] = SP1RawTokenComputer(model_name=se["model_name"], normalize_embeddings=se.get("normalize_embeddings", True), device=st_device)
        elif sp == "sp2_windowed_span":
            out[sp] = SP2WindowedSpanComputer(model_name=se["model_name"], window_k=cfg.get("sp2", {}).get("window_k", 5), normalize_embeddings=se.get("normalize_embeddings", True), device=st_device)
        else:
            raise ValueError(f"Unknown SP type: {sp}")
    return out

def append_record(records, base, metrics):
    records.append({**base, **metrics})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_e1_config(args.config)
    set_global_seed(cfg.seed)
    out_dir = Path(cfg.output_dir); dirs = ensure_dirs(out_dir)
    ds_path = Path(cfg.input.dataset_jsonl)
    if not ds_path.exists():
        # Helpful UX: auto-build domain samples if missing (common first-run issue).
        print(f"[WARN] dataset_jsonl not found: {ds_path}. Attempting to generate via scripts/sample_datasets.py ...", flush=True)
        try:
            import subprocess
            subprocess.check_call([sys.executable, "-m", "scripts.sample_datasets", "--config", args.config])
        except Exception as e:
            raise FileNotFoundError(
                f"Missing dataset_jsonl: {ds_path}. Run: python -m scripts.sample_datasets --config {args.config}"
            ) from e
        if not ds_path.exists():
            raise FileNotFoundError(
                f"dataset_jsonl still missing after sampling: {ds_path}. Run: python -m scripts.sample_datasets --config {args.config}"
            )

    examples = load_jsonl_examples(str(ds_path), max_examples=cfg.input.max_examples)
    if not examples: raise RuntimeError("No examples loaded.")
    all_records: List[Dict] = []; layer_records: List[Dict] = []; head_records: List[Dict] = []
    device = resolve_device(cfg.device)
    run_meta = {"timestamp_utc": datetime.utcnow().isoformat()+"Z", "num_examples": len(examples),
                "device": device, "torch_cuda": torch.cuda.is_available()}

    for model_cfg_obj in cfg.models:
        mc = model_cfg_obj.__dict__
        print(f"\n[Model] {mc['name']}")
        extractor = AttentionExtractor(model_cfg=mc, device=device)
        sp_computers = get_sp_computers({"sentence_encoder": cfg.sentence_encoder.__dict__,
                                          "sp_types": cfg.sp_types, "sp2": cfg.sp2.__dict__})
        tokenized_list = [extractor.tokenize_example(ex) for ex in tqdm(examples, desc="Tokenizing")]
        freq_dict = build_token_frequency_dict(tokenized_list)
        tok_by_id = {t.example_id: t for t in tokenized_list}

        for ex in tqdm(examples, desc=f"E1 {mc['name']}"):
            attn_art = extractor.extract(ex)
            valid_mask = make_valid_pair_mask(attn_art,
                exclude_self_pairs=cfg.filters.exclude_self_pairs,
                exclude_special_tokens=cfg.filters.exclude_special_tokens,
                causal_valid_only=cfg.filters.causal_valid_only)
            tokenized = tok_by_id[ex.example_id]
            sims: Dict[str, Any] = {}
            for sp_name, sp_comp in sp_computers.items():
                sims[sp_name] = sp_comp.compute(tokenized).similarity
            all_ctrl = compute_controls(tokenized=tokenized, freq_dict=freq_dict, seed=cfg.seed)
            for cn in cfg.controls:
                if cn in all_ctrl: sims[cn] = all_ctrl[cn]

            ex_json = {"example_id": ex.example_id, "domain": ex.domain,
                       "model_name": mc["name"], "seq_len": attn_art.seq_len,
                       "num_layers": attn_art.num_layers, "num_heads": attn_art.num_heads, "results": {}}

            if cfg.aggregation.include_model_mean:
                am = attn_art.attention.mean(axis=(0, 1))
                ex_json["results"]["model_mean"] = {}
                for sn, sm in sims.items():
                    r = evaluate_correlation(am, sm, valid_mask,
                        kendall_exact_max_pairs=cfg.metrics.kendall_exact_max_pairs,
                        kendall_sample_size=cfg.metrics.kendall_sample_size,
                        auc_top_quantile=cfg.metrics.auc_top_quantile, seed=cfg.seed)
                    ex_json["results"]["model_mean"][sn] = r.to_dict()
                    append_record(all_records, {"example_id": ex.example_id, "domain": ex.domain,
                        "model_name": mc["name"], "aggregation": "model_mean",
                        "layer": None, "head": None, "similarity_type": sn, "seq_len": attn_art.seq_len}, r.to_dict())

            if cfg.aggregation.include_layer_mean:
                ex_json["results"]["layer_mean"] = []
                for li in range(attn_art.num_layers):
                    la = attn_art.attention[li].mean(axis=0)
                    le = {"layer": li, "metrics": {}}
                    for sn, sm in sims.items():
                        r = evaluate_correlation(la, sm, valid_mask,
                            kendall_exact_max_pairs=cfg.metrics.kendall_exact_max_pairs,
                            kendall_sample_size=cfg.metrics.kendall_sample_size,
                            auc_top_quantile=cfg.metrics.auc_top_quantile, seed=cfg.seed)
                        le["metrics"][sn] = r.to_dict()
                        append_record(layer_records, {"example_id": ex.example_id, "domain": ex.domain,
                            "model_name": mc["name"], "aggregation": "layer_mean",
                            "layer": li, "head": None, "similarity_type": sn, "seq_len": attn_art.seq_len}, r.to_dict())
                    ex_json["results"]["layer_mean"].append(le)

            if cfg.aggregation.include_per_head:
                ex_json["results"]["per_head"] = []
                for li in range(attn_art.num_layers):
                    for hi in range(attn_art.num_heads):
                        ha = attn_art.attention[li, hi]
                        he = {"layer": li, "head": hi, "metrics": {}}
                        for sn, sm in sims.items():
                            r = evaluate_correlation(ha, sm, valid_mask,
                                kendall_exact_max_pairs=cfg.metrics.kendall_exact_max_pairs,
                                kendall_sample_size=cfg.metrics.kendall_sample_size,
                                auc_top_quantile=cfg.metrics.auc_top_quantile, seed=cfg.seed)
                            he["metrics"][sn] = r.to_dict()
                            append_record(head_records, {"example_id": ex.example_id, "domain": ex.domain,
                                "model_name": mc["name"], "aggregation": "per_head",
                                "layer": li, "head": hi, "similarity_type": sn, "seq_len": attn_art.seq_len}, r.to_dict())
                        ex_json["results"]["per_head"].append(he)

            if cfg.save.example_level_json:
                write_json(dirs["raw"] / f"{mc['name']}__{ex.example_id}.json", ex_json)

    if cfg.save.aggregate_csv:
        if all_records: pd.DataFrame(all_records).to_csv(dirs["agg"] / "correlation_summary.csv", index=False)
        if layer_records: pd.DataFrame(layer_records).to_csv(dirs["agg"] / "layer_summary.csv", index=False)
        if head_records: pd.DataFrame(head_records).to_csv(dirs["agg"] / "head_summary.csv", index=False)

    # ── Gating decision for E3 eligibility ──────────────────────────
    gating_path = dirs["agg"] / "gating_decision.json"
    if all_records:
        try:
            df = pd.DataFrame(all_records)
            df = df[df["aggregation"] == "model_mean"].copy()
            # pivot: domain × model × sp_type → spearman_rho
            pivot = df.groupby(["domain", "model_name", "similarity_type"])["spearman_rho"].mean().reset_index()
            # For each domain × sp_type, average across models
            domain_sp = pivot.groupby(["domain", "similarity_type"])["spearman_rho"].mean().reset_index()
            domain_scores = {}
            for _, row in domain_sp.iterrows():
                d = row["domain"]
                if d not in domain_scores:
                    domain_scores[d] = {}
                domain_scores[d][row["similarity_type"]] = round(float(row["spearman_rho"]), 4)
            # Best model × sp_type by mean spearman across domains
            model_sp_mean = pivot.groupby(["model_name", "similarity_type"])["spearman_rho"].mean().reset_index()
            best_row = model_sp_mean.loc[model_sp_mean["spearman_rho"].idxmax()]
            best_model = str(best_row["model_name"])
            best_sp = str(best_row["similarity_type"])
            # Rule: 3 of 4 domains must have model_mean Spearman >= 0.20 for the best sp_type
            best_sp_by_domain = domain_sp[domain_sp["similarity_type"] == best_sp]
            passing_domains = int((best_sp_by_domain["spearman_rho"] >= 0.20).sum())
            total_domains = len(best_sp_by_domain)
            eligible = passing_domains >= min(3, total_domains)
            gating = {
                "eligible_for_e3": eligible,
                "rule": "3_of_4_domains_model_mean_spearman_ge_0.20",
                "best_model": best_model,
                "best_sp_type": best_sp,
                "passing_domains": passing_domains,
                "total_domains": total_domains,
                "domain_scores": domain_scores,
            }
            write_json(gating_path, gating)
            print(f"Gating decision written: {gating_path}")
        except Exception as e:
            print(f"Warning: could not write gating decision: {e}")

    write_json(out_dir / "run_metadata.json", run_meta)
    print(f"\nDone. Results: {out_dir}")

if __name__ == "__main__":
    main()
