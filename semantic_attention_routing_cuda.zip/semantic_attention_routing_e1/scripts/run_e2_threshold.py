"""
E2: Threshold Sensitivity Sweep

Uses E1's cached attention and similarity matrices to compute the
efficiency-coverage tradeoff curve (CES — Concentration Efficiency Score).

For each (model, domain, sp_type) and a set of quantile-based thresholds,
computes:
  - retained_pair_fraction: fraction of valid pairs above threshold
  - retained_attention_mass: fraction of total attention on retained pairs
  - CES = retained_attention_mass / retained_pair_fraction

Output:
  results/e2/aggregates/threshold_sweep.csv
  results/e2/aggregates/break_even_summary.json

Usage:
    python scripts/run_e2_threshold.py --config configs/experiments/e1_correlation.yaml
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import numpy as np
import pandas as pd
from tqdm import tqdm

from sar.config import load_e1_config
from sar.data.schemas import Example
from sar.metrics.correlation import make_valid_pair_mask
from sar.models.attention_extractor import AttentionExtractor
from sar.semantics.controls import build_token_frequency_dict, compute_controls
from sar.semantics.sp1_raw_token import SP1RawTokenComputer
from sar.semantics.sp2_windowed_span import SP2WindowedSpanComputer
from sar.utils.device import resolve_device
from sar.utils.io import load_jsonl_examples, write_json
from sar.utils.seeds import set_global_seed

# Quantile-based thresholds: top X% of similarity values are retained
THRESHOLDS = [0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 0.98]


def compute_threshold_metrics(
    attention_matrix: np.ndarray,
    similarity_matrix: np.ndarray,
    valid_mask: np.ndarray,
    threshold_quantile: float,
) -> Dict[str, float]:
    """
    For a given similarity quantile threshold:
    - Compute the similarity cutoff at that quantile
    - Mask = (similarity >= cutoff) & valid_mask
    - retained_pair_fraction = |mask| / |valid_mask|
    - retained_attention_mass = sum(attention[mask]) / sum(attention[valid_mask])
    - CES = retained_attention_mass / retained_pair_fraction
    """
    sim_valid = similarity_matrix[valid_mask]
    attn_valid = attention_matrix[valid_mask]

    if sim_valid.size == 0 or attn_valid.size == 0:
        return {
            "threshold_quantile": threshold_quantile,
            "similarity_cutoff": 0.0,
            "retained_pair_fraction": 0.0,
            "retained_attention_mass": 0.0,
            "ces": 0.0,
            "num_valid_pairs": 0,
            "num_retained_pairs": 0,
        }

    # Compute cutoff: keep pairs with similarity >= this value
    # quantile is "top X%", so cutoff = percentile at (threshold_quantile * 100)
    cutoff = float(np.quantile(sim_valid, threshold_quantile))

    # Mask: retained pairs are those with similarity >= cutoff
    high_sim_mask = similarity_matrix >= cutoff
    retained_mask = valid_mask & high_sim_mask

    total_valid = int(valid_mask.sum())
    num_retained = int(retained_mask.sum())

    retained_pair_fraction = num_retained / max(total_valid, 1)

    total_attn_mass = float(attn_valid.sum())
    retained_attn_mass = float(attention_matrix[retained_mask].sum()) if num_retained > 0 else 0.0
    retained_attention_mass = retained_attn_mass / max(total_attn_mass, 1e-12)

    ces = retained_attention_mass / max(retained_pair_fraction, 1e-12)

    return {
        "threshold_quantile": threshold_quantile,
        "similarity_cutoff": round(cutoff, 6),
        "retained_pair_fraction": round(retained_pair_fraction, 6),
        "retained_attention_mass": round(retained_attention_mass, 6),
        "ces": round(ces, 4),
        "num_valid_pairs": total_valid,
        "num_retained_pairs": num_retained,
    }


def find_break_even(records: List[Dict], target_mass: float = 0.80) -> Dict[str, Any]:
    """Find break-even per (model, domain, similarity_type).

    Definition (aggressive operating point): the **highest** threshold_quantile
    such that retained_attention_mass >= target_mass.

    Fallback: if no threshold satisfies the target, pick the threshold with the
    highest retained_attention_mass (tie-break: higher threshold_quantile).
    """
    df = pd.DataFrame(records)
    if df.empty:
        return {"break_even_threshold": None, "note": "no data"}

    # Group by model × domain × sp_type
    groups = df.groupby(["model_name", "domain", "similarity_type"])
    results = {}

    for (model, domain, sp_type), g in groups:
        g_sorted = g.sort_values("threshold_quantile", ascending=False)
        be_row = None

        # Prefer the highest quantile that still meets target_mass
        for _, row in g_sorted.iterrows():
            if float(row["retained_attention_mass"]) >= float(target_mass):
                be_row = row
                break

        # If none meet target, pick the row with max attention mass
        if be_row is None:
            g_best = g.sort_values(
                ["retained_attention_mass", "threshold_quantile"], ascending=[False, False]
            )
            be_row = g_best.iloc[0]

        be = float(be_row["threshold_quantile"]) if be_row is not None else None
        key = f"{model}__{domain}__{sp_type}"
        results[key] = {
            "model": model,
            "domain": domain,
            "sp_type": sp_type,
            "break_even_quantile": be,
            "target_mass": float(target_mass),
            "retained_attention_at_break_even": float(be_row["retained_attention_mass"]) if be_row is not None else None,
            "retained_pairs_at_break_even": float(be_row["retained_pair_fraction"]) if be_row is not None else None,
        }

    return results


def get_sp_computers(cfg) -> Dict[str, Any]:
    out = {}
    se = cfg.sentence_encoder
    for sp in cfg.sp_types:
        if sp == "sp1_raw_token":
            out[sp] = SP1RawTokenComputer(
                model_name=se.model_name,
                normalize_embeddings=se.normalize_embeddings,
            )
        elif sp == "sp2_windowed_span":
            out[sp] = SP2WindowedSpanComputer(
                model_name=se.model_name,
                window_k=cfg.sp2.window_k,
                normalize_embeddings=getattr(cfg.sp2, "normalize_embeddings", True),
            )
    return out


def main():
    parser = argparse.ArgumentParser(description="E2: Threshold Sensitivity Sweep")
    parser.add_argument("--config", required=True, help="Experiment YAML config")
    parser.add_argument("--thresholds", nargs="*", type=float, default=THRESHOLDS,
                        help="Quantile thresholds to sweep")
    parser.add_argument("--output_dir", default="results/e2",
                        help="Output directory (default: results/e2)")
    parser.add_argument("--target_mass", type=float, default=0.80,
                        help="Break-even target: retained_attention_mass >= target_mass (default: 0.80)")
    args = parser.parse_args()

    cfg = load_e1_config(args.config)
    set_global_seed(cfg.seed)
    device = resolve_device(cfg.device)

    out_dir = Path(args.output_dir)
    agg_dir = out_dir / "aggregates"
    agg_dir.mkdir(parents=True, exist_ok=True)

    examples = load_jsonl_examples(cfg.input.dataset_jsonl, max_examples=cfg.input.max_examples)
    if not examples:
        raise RuntimeError("No examples loaded.")

    all_records: List[Dict] = []

    for model_cfg_obj in cfg.models:
        mc = model_cfg_obj.__dict__
        print(f"\n[Model] {mc['name']}")

        extractor = AttentionExtractor(model_cfg=mc, device=device)
        sp_computers = get_sp_computers(cfg)

        tokenized_list = [extractor.tokenize_example(ex) for ex in examples]
        freq_dict = build_token_frequency_dict(tokenized_list)
        tok_by_id = {t.example_id: t for t in tokenized_list}

        for ex in tqdm(examples, desc=f"E2 {mc['name']}"):
            attn_art = extractor.extract(ex)
            valid_mask = make_valid_pair_mask(
                attn_art,
                exclude_self_pairs=cfg.filters.exclude_self_pairs,
                exclude_special_tokens=cfg.filters.exclude_special_tokens,
                causal_valid_only=cfg.filters.causal_valid_only,
            )

            # Model-mean attention
            attn_model_mean = attn_art.attention.mean(axis=(0, 1))

            tokenized = tok_by_id[ex.example_id]

            # Compute similarities
            for sp_name, sp_comp in sp_computers.items():
                sim_artifact = sp_comp.compute(tokenized)
                sim_matrix = sim_artifact.similarity

                for thr in args.thresholds:
                    metrics = compute_threshold_metrics(
                        attn_model_mean, sim_matrix, valid_mask, thr
                    )
                    record = {
                        "example_id": ex.example_id,
                        "domain": ex.domain,
                        "model_name": mc["name"],
                        "similarity_type": sp_name,
                        "seq_len": attn_art.seq_len,
                        **metrics,
                    }
                    all_records.append(record)

            # Also run on controls (positional_distance specifically)
            all_ctrl = compute_controls(tokenized=tokenized, freq_dict=freq_dict, seed=cfg.seed)
            if "positional_distance" in all_ctrl:
                pos_sim = all_ctrl["positional_distance"]
                for thr in args.thresholds:
                    metrics = compute_threshold_metrics(
                        attn_model_mean, pos_sim, valid_mask, thr
                    )
                    record = {
                        "example_id": ex.example_id,
                        "domain": ex.domain,
                        "model_name": mc["name"],
                        "similarity_type": "positional_distance",
                        "seq_len": attn_art.seq_len,
                        **metrics,
                    }
                    all_records.append(record)

    # Write threshold sweep CSV
    if all_records:
        df = pd.DataFrame(all_records)
        csv_path = agg_dir / "threshold_sweep.csv"
        df.to_csv(csv_path, index=False)
        print(f"\nThreshold sweep → {csv_path} ({len(df)} rows)")

        # Break-even summary
        # Average across examples first
        avg_df = df.groupby(
            ["model_name", "domain", "similarity_type", "threshold_quantile"]
        ).agg({
            "retained_pair_fraction": "mean",
            "retained_attention_mass": "mean",
            "ces": "mean",
        }).reset_index()

        be_summary = find_break_even(avg_df.to_dict("records"), target_mass=args.target_mass)
        be_path = agg_dir / "break_even_summary.json"
        write_json(be_path, {
            "timestamp_utc": datetime.utcnow().isoformat() + "Z",
            "thresholds_tested": args.thresholds,
            "target_mass": args.target_mass,
            "num_examples": len(examples),
            "num_models": len(cfg.models),
            "break_even_analysis": be_summary,
        })
        print(f"Break-even summary → {be_path}")
    else:
        print("WARNING: No records generated")

    # Run metadata
    write_json(out_dir / "run_metadata.json", {
        "timestamp_utc": datetime.utcnow().isoformat() + "Z",
        "experiment": "e2_threshold_sweep",
        "config": args.config,
        "thresholds": args.thresholds,
        "num_examples": len(examples),
        "device": device,
    })
    print(f"\nDone. Results: {out_dir}")


if __name__ == "__main__":
    main()
