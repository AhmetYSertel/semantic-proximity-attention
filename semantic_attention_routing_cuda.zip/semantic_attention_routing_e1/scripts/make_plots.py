"""
Generate publication-ready figures from E1 correlation analysis results.

Figure 1: Model-mean Spearman bar chart (similarity_type × domain, per model subplot)
Figure 2: Layer-wise Spearman heatmap (layer × domain, sp2_windowed_span)
Figure 3: SP1 vs SP2 vs positional_distance grouped comparison

Usage:
    python scripts/make_plots.py --results_dir results/e1
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import pandas as pd
import seaborn as sns

# ── Style config ────────────────────────────────────────────────────
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "legend.fontsize": 9,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.1,
})

PALETTE = sns.color_palette("Set2", 8)

# Ordering for x-axis
SIM_TYPE_ORDER = [
    "sp1_raw_token", "sp2_windowed_span",
    "random", "positional_distance", "lexical_overlap", "frequency_baseline",
]

SIM_TYPE_LABELS = {
    "sp1_raw_token": "SP1\n(raw token)",
    "sp2_windowed_span": "SP2\n(windowed)",
    "random": "Random\n(control)",
    "positional_distance": "Positional\n(control)",
    "lexical_overlap": "Lexical\n(control)",
    "frequency_baseline": "Frequency\n(control)",
}


def load_data(results_dir: Path):
    agg = results_dir / "aggregates"
    dfs = {}
    for name in ["correlation_summary", "layer_summary", "head_summary"]:
        p = agg / f"{name}.csv"
        if p.exists():
            dfs[name] = pd.read_csv(p)
            print(f"  Loaded {name}: {len(dfs[name])} rows")
        else:
            print(f"  Warning: {p} not found")
    return dfs


def figure1_model_mean_bar(df: pd.DataFrame, plots_dir: Path):
    """Model mean Spearman bar chart: x=similarity_type, y=spearman_rho, hue=domain."""
    mm = df[df["aggregation"] == "model_mean"].copy()
    if mm.empty:
        print("  Skipping Figure 1: no model_mean data")
        return

    models = sorted(mm["model_name"].unique())
    n_models = len(models)
    fig, axes = plt.subplots(1, n_models, figsize=(5 * n_models, 4.5), sharey=True)
    if n_models == 1:
        axes = [axes]

    domains = sorted(mm["domain"].unique())

    for ax, model in zip(axes, models):
        sub = mm[mm["model_name"] == model]
        # Average across examples
        grouped = sub.groupby(["similarity_type", "domain"])["spearman_rho"].mean().reset_index()

        # Filter to known types and order
        present_types = [t for t in SIM_TYPE_ORDER if t in grouped["similarity_type"].values]
        grouped = grouped[grouped["similarity_type"].isin(present_types)]

        pivot = grouped.pivot(index="similarity_type", columns="domain", values="spearman_rho")
        pivot = pivot.reindex(present_types)

        x = np.arange(len(present_types))
        width = 0.8 / len(domains)

        for i, domain in enumerate(domains):
            if domain in pivot.columns:
                vals = pivot[domain].fillna(0).values
                ax.bar(x + i * width - 0.4 + width / 2, vals, width,
                       label=domain, color=PALETTE[i], edgecolor="white", linewidth=0.5)

        ax.set_xticks(x)
        ax.set_xticklabels([SIM_TYPE_LABELS.get(t, t) for t in present_types], ha="center")
        ax.set_title(model, fontweight="bold")
        ax.axhline(y=0, color="grey", linewidth=0.5, linestyle="--")
        ax.set_ylabel("Spearman ρ" if ax == axes[0] else "")
        ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

    axes[-1].legend(title="Domain", bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.suptitle("Figure 1: Model-Mean Spearman Correlation by Similarity Type", fontweight="bold", y=1.02)
    plt.tight_layout()

    out = plots_dir / "fig1_model_mean_spearman.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  Saved: {out}")


def figure2_layer_heatmap(df: pd.DataFrame, plots_dir: Path):
    """Layer-wise Spearman heatmap for sp2_windowed_span."""
    if df is None or df.empty:
        print("  Skipping Figure 2: no layer data")
        return

    sp2 = df[df["similarity_type"] == "sp2_windowed_span"].copy()
    if sp2.empty:
        # Fallback to sp1
        sp2 = df[df["similarity_type"] == "sp1_raw_token"].copy()
        sp_label = "SP1 (raw token)"
    else:
        sp_label = "SP2 (windowed span)"

    if sp2.empty:
        print("  Skipping Figure 2: no SP data in layer summary")
        return

    models = sorted(sp2["model_name"].unique())
    n_models = len(models)
    fig, axes = plt.subplots(1, n_models, figsize=(6 * n_models, 4), sharey=True)
    if n_models == 1:
        axes = [axes]

    for ax, model in zip(axes, models):
        sub = sp2[sp2["model_name"] == model]
        # Average across examples: layer × domain → spearman_rho
        grouped = sub.groupby(["layer", "domain"])["spearman_rho"].mean().reset_index()
        pivot = grouped.pivot(index="domain", columns="layer", values="spearman_rho")
        pivot = pivot.sort_index()

        sns.heatmap(
            pivot, ax=ax, cmap="RdBu_r", center=0, vmin=-0.3, vmax=0.5,
            linewidths=0.5, linecolor="white",
            cbar_kws={"label": "Spearman ρ", "shrink": 0.8},
            annot=True, fmt=".2f", annot_kws={"size": 7},
        )
        ax.set_title(f"{model}", fontweight="bold")
        ax.set_xlabel("Layer Index")
        ax.set_ylabel("Domain" if ax == axes[0] else "")

    fig.suptitle(f"Figure 2: Layer-wise Spearman Correlation ({sp_label})", fontweight="bold", y=1.02)
    plt.tight_layout()

    out = plots_dir / "fig2_layer_heatmap.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  Saved: {out}")


def figure3_sp_comparison(df: pd.DataFrame, plots_dir: Path):
    """SP1 vs SP2 vs positional_distance grouped bar chart across all domains."""
    mm = df[df["aggregation"] == "model_mean"].copy()
    compare_types = ["sp1_raw_token", "sp2_windowed_span", "positional_distance"]
    present = [t for t in compare_types if t in mm["similarity_type"].values]
    if not present:
        print("  Skipping Figure 3: no comparison data")
        return

    sub = mm[mm["similarity_type"].isin(present)]
    # Average across models and examples
    grouped = sub.groupby(["domain", "similarity_type"])["spearman_rho"].mean().reset_index()

    domains = sorted(grouped["domain"].unique())
    x = np.arange(len(domains))
    width = 0.8 / len(present)

    fig, ax = plt.subplots(figsize=(max(6, len(domains) * 1.5), 4.5))

    type_labels = {
        "sp1_raw_token": "SP1 (raw token)",
        "sp2_windowed_span": "SP2 (windowed span)",
        "positional_distance": "Positional distance",
    }

    for i, stype in enumerate(present):
        vals = []
        for d in domains:
            v = grouped[(grouped["domain"] == d) & (grouped["similarity_type"] == stype)]["spearman_rho"]
            vals.append(float(v.iloc[0]) if len(v) > 0 else 0.0)
        ax.bar(x + i * width - 0.4 + width / 2, vals, width,
               label=type_labels.get(stype, stype), color=PALETTE[i],
               edgecolor="white", linewidth=0.5)

    ax.set_xticks(x)
    ax.set_xticklabels(domains)
    ax.set_ylabel("Spearman ρ")
    ax.set_xlabel("Domain")
    ax.axhline(y=0, color="grey", linewidth=0.5, linestyle="--")
    ax.legend(title="Similarity Type")
    ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))
    ax.set_title("Figure 3: SP1 vs SP2 vs Positional Distance", fontweight="bold")

    plt.tight_layout()
    out = plots_dir / "fig3_sp_comparison.png"
    fig.savefig(out, dpi=300)
    plt.close(fig)
    print(f"  Saved: {out}")


def main():
    parser = argparse.ArgumentParser(description="Generate SAR E1 publication-ready figures")
    parser.add_argument("--results_dir", required=True, help="Path to E1 results directory")
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    plots_dir = results_dir / "plots"
    plots_dir.mkdir(parents=True, exist_ok=True)

    print(f"Loading data from {results_dir}...")
    dfs = load_data(results_dir)

    corr = dfs.get("correlation_summary")
    layer = dfs.get("layer_summary")

    if corr is not None and not corr.empty:
        print("\nGenerating Figure 1...")
        figure1_model_mean_bar(corr, plots_dir)
        print("Generating Figure 3...")
        figure3_sp_comparison(corr, plots_dir)
    else:
        print("WARNING: correlation_summary.csv not found, skipping Figures 1 & 3")

    if layer is not None and not layer.empty:
        print("Generating Figure 2...")
        figure2_layer_heatmap(layer, plots_dir)
    else:
        print("WARNING: layer_summary.csv not found, skipping Figure 2")

    print(f"\nAll plots saved to: {plots_dir}")


if __name__ == "__main__":
    main()
