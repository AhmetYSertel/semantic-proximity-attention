from __future__ import annotations

import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import argparse
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch
import yaml
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer

from sar.data.schemas import TokenizedExample
from sar.models.pairwise_masking import apply_pairwise_mask_gpt2
from sar.semantics.sp2_windowed_span import SP2WindowedSpanComputer


def _load_yaml(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _special_ids(tokenizer) -> set[int]:
    ids = set()
    for tid in [
        tokenizer.pad_token_id,
        tokenizer.bos_token_id,
        tokenizer.eos_token_id,
        tokenizer.sep_token_id,
        tokenizer.cls_token_id,
    ]:
        if tid is not None:
            ids.add(int(tid))
    return ids


def tokenize_text(
    *,
    model_name: str,
    text: str,
    tokenizer,
    max_length: int,
    exclude_special: bool = True,
) -> TokenizedExample:
    enc = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=max_length,
        return_offsets_mapping=True,
        padding=False,
        add_special_tokens=True,
    )
    ids = enc["input_ids"][0].tolist()
    attn_mask = enc["attention_mask"][0].tolist()
    offsets = [tuple(x) for x in enc["offset_mapping"][0].tolist()]
    tokens = tokenizer.convert_ids_to_tokens(ids)
    sp_ids = _special_ids(tokenizer)
    valid = [
        i
        for i, (tid, am) in enumerate(zip(ids, attn_mask))
        if am == 1 and (not exclude_special or tid not in sp_ids)
    ]
    return TokenizedExample(
        example_id="0",
        domain="lm",
        text=text,
        tokens=tokens,
        token_ids=ids,
        attention_mask=attn_mask,
        offset_mapping=offsets,
        valid_token_indices=valid,
        model_name=model_name,
    )


def build_keep_mask(sim: np.ndarray, valid_idx: List[int], quantile: float) -> np.ndarray:
    seq = sim.shape[0]
    keep = np.zeros((seq, seq), dtype=bool)
    if len(valid_idx) < 2:
        np.fill_diagonal(keep, True)
        return keep
    vv = np.ix_(valid_idx, valid_idx)
    vals = sim[vv].reshape(-1)
    thr = np.quantile(vals, quantile)
    keep[vv] = sim[vv] >= thr
    np.fill_diagonal(keep, True)
    # enforce causal: only attend to <= i
    keep = np.tril(keep)
    return keep


@torch.no_grad()
def avg_nll(
    model,
    tokenizer,
    sp2: SP2WindowedSpanComputer,
    texts: List[str],
    *,
    max_length: int,
    quantile: float,
    device: str,
    sar: bool,
) -> float:
    model.eval()
    model.to(device)

    # We provide mask per batch item; here we run batch_size=1 for simplicity.
    losses: List[float] = []

    for t in texts:
        tok = tokenize_text(model_name=model.config._name_or_path, text=t, tokenizer=tokenizer, max_length=max_length)
        inputs = tokenizer(
            t,
            return_tensors="pt",
            truncation=True,
            max_length=max_length,
            padding=False,
            add_special_tokens=True,
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}
        labels = inputs["input_ids"].clone()

        unpatch = None
        if sar:
            sim_art = sp2.compute(tok)
            keep_np = build_keep_mask(sim_art.similarity, tok.valid_token_indices, quantile)
            keep_t = torch.from_numpy(keep_np).bool()

            def provider(_batch_index: int) -> torch.Tensor:
                return keep_t

            unpatch = apply_pairwise_mask_gpt2(model, provider)

        out = model(**inputs, labels=labels)
        loss = float(out.loss.detach().cpu().item())
        losses.append(loss)

        if unpatch is not None:
            unpatch()

    return float(np.mean(losses))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--limit", type=int, default=50)
    args = ap.parse_args()

    cfg = _load_yaml(args.config)

    device = cfg.get("device", "cuda" if torch.cuda.is_available() else "cpu")
    model_id = cfg.get("model_id", "gpt2")
    max_length = int(cfg.get("max_length", 256))
    quantile = float(cfg.get("similarity_quantile", 0.95))

    out_dir = Path(cfg.get("output_dir", "results/e3_decoder"))
    _ensure_dir(out_dir)

    ds = load_dataset("wikitext", "wikitext-2-raw-v1", split="test")
    # Filter empty lines and take first N
    texts = [x["text"] for x in ds if x.get("text") and x["text"].strip()]
    texts = texts[: args.limit]

    tokenizer = AutoTokenizer.from_pretrained(model_id, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(model_id)

    sp2 = SP2WindowedSpanComputer(
        model_name=cfg.get("sentence_transformer_id", "all-MiniLM-L6-v2"),
        window_k=int(cfg.get("sp2_window_k", 5)),
        normalize_embeddings=bool(cfg.get("normalize_embeddings", True)),
    )

    nll_full = avg_nll(
        model,
        tokenizer,
        sp2,
        texts,
        max_length=max_length,
        quantile=quantile,
        device=device,
        sar=False,
    )
    nll_sar = avg_nll(
        model,
        tokenizer,
        sp2,
        texts,
        max_length=max_length,
        quantile=quantile,
        device=device,
        sar=True,
    )

    summary = {
        "nll_full": float(nll_full),
        "nll_sar": float(nll_sar),
        "delta_nll": float(nll_sar - nll_full),
        "ppl_full": float(np.exp(nll_full)),
        "ppl_sar": float(np.exp(nll_sar)),
        "delta_ppl": float(np.exp(nll_sar) - np.exp(nll_full)),
        "n": int(len(texts)),
    }

    (out_dir / "e3_decoder_summary.yaml").write_text(yaml.safe_dump(summary, sort_keys=False), encoding="utf-8")
    print(yaml.safe_dump(summary, sort_keys=False))


if __name__ == "__main__":
    main()
