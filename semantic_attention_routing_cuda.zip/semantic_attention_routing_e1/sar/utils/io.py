from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from sar.data.schemas import Example


def read_yaml(path: str | Path) -> Dict[str, Any]:
    path = Path(path)
    with path.open('r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data or {}


def write_json(path: str | Path, data: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_jsonl_examples(path: str | Path, max_examples: Optional[int] = None) -> List[Example]:
    path = Path(path)
    out: List[Example] = []
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            out.append(Example(
                example_id=str(obj['example_id']),
                domain=str(obj['domain']),
                text=str(obj['text']),
            ))
            if max_examples is not None and len(out) >= max_examples:
                break
    return out
