from __future__ import annotations

import torch


def resolve_device(device: str) -> str:
    if device == 'cuda' and torch.cuda.is_available():
        return 'cuda'
    return 'cpu'
