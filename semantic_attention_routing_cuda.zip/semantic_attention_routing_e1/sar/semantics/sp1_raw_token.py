from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Dict, List
import numpy as np
from sar.data.schemas import SimilarityArtifact, TokenizedExample

_PREFIX = re.compile(r"^(##|Ġ|▁)")

def clean_token(t: str) -> str:
    return _PREFIX.sub("", t).strip()

def _cosine_sim(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.float32)
    norms = np.linalg.norm(x, axis=1, keepdims=True).clip(1e-12)
    return (x / norms) @ (x / norms).T

@dataclass
class SP1RawTokenComputer:
    model_name: str
    normalize_embeddings: bool = True
    device: str = "cpu"
    _cache: Dict[str, np.ndarray] = field(default_factory=dict, init=False, repr=False)

    def _get_encoder(self):
        # Shared singleton encoder to avoid repeated weight materialization.
        from sar.semantics.model_cache import get_sentence_encoder
        return get_sentence_encoder(self.model_name, device=self.device)

    def compute(self, tokenized: TokenizedExample) -> SimilarityArtifact:
        cleaned = [clean_token(t) or "[EMPTY]" for t in tokenized.tokens]
        missing = [t for t in set(cleaned) if t not in self._cache]
        if missing:
            enc = self._get_encoder()
            embs = enc.encode(missing, normalize_embeddings=self.normalize_embeddings,
                              convert_to_numpy=True, show_progress_bar=False)
            for t, e in zip(missing, embs):
                self._cache[t] = e.astype(np.float32)
        vecs = np.stack([self._cache[t] for t in cleaned])
        sim = _cosine_sim(vecs)
        return SimilarityArtifact(example_id=tokenized.example_id,
                                   model_name=tokenized.model_name,
                                   sp_type="sp1_raw_token", similarity=sim)
