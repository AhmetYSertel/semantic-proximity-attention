from __future__ import annotations

"""Lightweight shared cache for sentence-transformers encoders.

E1/E2/E3 can construct multiple SP computers across models and runs.
SentenceTransformer() construction is expensive (weight materialization) even
when the model weights are already present on disk.

We cache encoders per (model_id, device) to avoid repeated loads.
"""

from functools import lru_cache

from sentence_transformers import SentenceTransformer


@lru_cache(maxsize=8)
def get_sentence_encoder(model_id: str, device: str = "cpu") -> SentenceTransformer:
    return SentenceTransformer(model_id, device=device)
