from __future__ import annotations
import math, re
from typing import Dict, Iterable, List
import numpy as np
from sar.data.schemas import TokenizedExample

_PREFIX = re.compile(r"^(##|Ġ|▁)")
def clean_token(t): return _PREFIX.sub("", t).strip()

def build_token_frequency_dict(examples: Iterable[TokenizedExample]) -> Dict[str, int]:
    freq: Dict[str, int] = {}
    for ex in examples:
        for i in ex.valid_token_indices:
            t = clean_token(ex.tokens[i])
            if t: freq[t] = freq.get(t, 0) + 1
    return freq

def compute_controls(tokenized: TokenizedExample, freq_dict: Dict[str, int], seed: int = 42) -> Dict[str, np.ndarray]:
    tokens = tokenized.tokens
    n = len(tokens)
    rng = np.random.default_rng(seed)

    # NC-1: random
    r = rng.random((n, n)).astype(np.float32)
    r = (r + r.T) / 2

    # NC-2: positional
    idx = np.arange(n)
    pos = 1.0 - np.abs(idx[:, None] - idx[None, :]).astype(np.float32) / max(n - 1, 1)

    # NC-3: lexical jaccard (optimized)
    sets = [set(clean_token(t)) for t in tokens]
    jac = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        if not sets[i]: continue
        jac[i, i] = 1.0
        for j in range(i + 1, n):
            if not sets[j]: continue
            inter = len(sets[i] & sets[j])
            if inter:
                score = inter / len(sets[i] | sets[j])
                jac[i, j] = jac[j, i] = score

    # NC-4: frequency
    lf = np.array([math.log1p(freq_dict.get(clean_token(t), 1)) for t in tokens], dtype=np.float32)
    freq_mat = (lf[:, None] + lf[None, :]) / 2
    if freq_mat.max() > 0: freq_mat /= freq_mat.max()

    return {"random": r, "positional_distance": pos, "lexical_overlap": jac, "frequency_baseline": freq_mat}
