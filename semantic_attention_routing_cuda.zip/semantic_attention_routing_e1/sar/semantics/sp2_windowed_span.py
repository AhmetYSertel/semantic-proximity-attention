from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Dict, List
import numpy as np
from sar.data.schemas import SimilarityArtifact, TokenizedExample

_PREFIX = re.compile(r"^(##|Ġ|▁)")

def clean_token(t: str) -> str:
    return _PREFIX.sub("", t).strip()

def _cosine_sim(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.float32)
    norms = np.linalg.norm(x, axis=1, keepdims=True).clip(1e-12)
    return (x / norms) @ (x / norms).T

@dataclass
class SP2WindowedSpanComputer:
    model_name: str
    window_k: int = 5
    normalize_embeddings: bool = True
    device: str = "cpu"
    _cache: Dict[str, np.ndarray] = field(default_factory=dict, init=False, repr=False)

    def _get_encoder(self):
        from sar.semantics.model_cache import get_sentence_encoder
        return get_sentence_encoder(self.model_name, device=self.device)

    def _span(self, tokens: List[str], i: int) -> str:
        lo, hi = max(0, i - self.window_k), min(len(tokens), i + self.window_k + 1)
        parts = [clean_token(t) for t in tokens[lo:hi] if clean_token(t)]
        return " ".join(parts) or "[EMPTY]"

    def compute(self, tokenized: TokenizedExample) -> SimilarityArtifact:
        spans = [self._span(tokenized.tokens, i) for i in range(len(tokenized.tokens))]
        missing = [s for s in set(spans) if s not in self._cache]
        if missing:
            enc = self._get_encoder()
            embs = enc.encode(missing, normalize_embeddings=self.normalize_embeddings,
                              convert_to_numpy=True, show_progress_bar=False)
            for s, e in zip(missing, embs):
                self._cache[s] = e.astype(np.float32)
        vecs = np.stack([self._cache[s] for s in spans])
        sim = _cosine_sim(vecs)
        return SimilarityArtifact(example_id=tokenized.example_id,
                                   model_name=tokenized.model_name,
                                   sp_type="sp2_windowed_span", similarity=sim)
