from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import numpy as np

@dataclass
class Example:
    example_id: str
    domain: str
    text: str

@dataclass
class TokenizedExample:
    example_id: str
    domain: str
    text: str
    tokens: List[str]
    token_ids: List[int]
    attention_mask: List[int]
    offset_mapping: List[Tuple[int, int]]
    valid_token_indices: List[int]
    model_name: str

@dataclass
class AttentionArtifact:
    example_id: str
    domain: str
    model_name: str
    tokens: List[str]
    token_ids: List[int]
    attention: np.ndarray
    valid_token_indices: List[int]
    causal: bool
    seq_len: int
    num_layers: int
    num_heads: int

@dataclass
class SimilarityArtifact:
    example_id: str
    model_name: str
    sp_type: str
    similarity: np.ndarray
