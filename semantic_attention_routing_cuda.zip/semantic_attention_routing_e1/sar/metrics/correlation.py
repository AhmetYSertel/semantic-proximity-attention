from __future__ import annotations
from dataclasses import asdict, dataclass
from typing import Dict, Tuple
import numpy as np
from scipy.stats import kendalltau, spearmanr
from sklearn.metrics import roc_auc_score
from sar.data.schemas import AttentionArtifact

@dataclass
class CorrelationResult:
    spearman_rho: float; spearman_p: float
    kendall_tau: float; kendall_p: float
    auc: float; num_pairs: int; num_pos_pairs: int; num_neg_pairs: int

    def to_dict(self): return asdict(self)

def make_valid_pair_mask(art: AttentionArtifact, exclude_self_pairs=True,
                          exclude_special_tokens=True, causal_valid_only=True) -> np.ndarray:
    n = art.seq_len
    mask = np.ones((n, n), dtype=bool)
    if exclude_self_pairs: np.fill_diagonal(mask, False)
    if exclude_special_tokens:
        v = np.zeros(n, dtype=bool)
        v[list(art.valid_token_indices)] = True
        mask &= v[:, None] & v[None, :]
    if causal_valid_only and art.causal:
        mask &= np.tril(np.ones((n, n), dtype=bool))
    return mask

def evaluate_correlation(attention_matrix, similarity_matrix, valid_mask,
                          kendall_exact_max_pairs=300, kendall_sample_size=10000,
                          auc_top_quantile=0.10, seed=42) -> CorrelationResult:
    assert attention_matrix.shape == similarity_matrix.shape == valid_mask.shape
    attn = attention_matrix[valid_mask]
    sim = similarity_matrix[valid_mask]

    if attn.size < 4:
        return CorrelationResult(0.,1.,0.,1.,0.5,int(attn.size),0,0)

    def safe_spearman(x, y):
        if np.allclose(x, x[0]) or np.allclose(y, y[0]): return 0., 1.
        r, p = spearmanr(x, y); return float(r), float(p)

    def safe_kendall(x, y):
        if np.allclose(x, x[0]) or np.allclose(y, y[0]): return 0., 1.
        if x.size > kendall_exact_max_pairs:
            rng = np.random.default_rng(seed)
            idx = rng.choice(x.size, min(kendall_sample_size, x.size), replace=False)
            x, y = x[idx], y[idx]
        r, p = kendalltau(x, y); return float(r), float(p)

    sp_r, sp_p = safe_spearman(attn, sim)
    kt_r, kt_p = safe_kendall(attn.copy(), sim.copy())

    # AUC
    q_hi = np.quantile(attn, 1 - auc_top_quantile)
    q_lo = np.quantile(attn, auc_top_quantile)
    pm = attn >= q_hi; nm = attn <= q_lo
    auc_val, npos, nneg = 0.5, int(pm.sum()), int(nm.sum())
    if npos > 0 and nneg > 0:
        yt = np.concatenate([np.ones(npos, dtype=int), np.zeros(nneg, dtype=int)])
        ys = np.concatenate([sim[pm], sim[nm]])
        if not np.allclose(ys, ys[0]):
            auc_val = float(roc_auc_score(yt, ys))

    return CorrelationResult(sp_r, sp_p, kt_r, kt_p, auc_val, int(attn.size), npos, nneg)
