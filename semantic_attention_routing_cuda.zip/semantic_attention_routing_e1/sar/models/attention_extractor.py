from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer
from sar.data.schemas import AttentionArtifact, Example, TokenizedExample

@dataclass
class _ModelBundle:
    tokenizer: Any
    model: Any

class AttentionExtractor:
    def __init__(self, model_cfg: Dict[str, Any], device: str = "cpu") -> None:
        self.name = model_cfg["name"]
        self.hf_id = model_cfg["hf_id"]
        self.family = model_cfg.get("family", "")
        self.causal = bool(model_cfg.get("causal", False))
        self.max_length = int(model_cfg.get("max_length", 512))
        self.exclude_special_tokens = bool(model_cfg.get("exclude_special_tokens", True))
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(self.hf_id, use_fast=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token or self.tokenizer.unk_token
        try:
            self.model = AutoModel.from_pretrained(
                self.hf_id, output_attentions=True, attn_implementation="eager"
            ).to(device)
        except TypeError:
            self.model = AutoModel.from_pretrained(
                self.hf_id, output_attentions=True
            ).to(device)
        self.model.eval()
        self._special_ids = self._get_special_ids()

    def _get_special_ids(self):
        ids = set()
        for tid in [self.tokenizer.cls_token_id, self.tokenizer.sep_token_id,
                    self.tokenizer.pad_token_id, self.tokenizer.bos_token_id,
                    self.tokenizer.eos_token_id]:
            if tid is not None:
                ids.add(int(tid))
        return ids

    def tokenize_example(self, example: Example) -> TokenizedExample:
        enc = self.tokenizer(
            example.text, return_tensors="pt", truncation=True,
            max_length=self.max_length, return_offsets_mapping=True,
            padding=False, add_special_tokens=True,
        )
        ids = enc["input_ids"][0].tolist()
        attn_mask = enc["attention_mask"][0].tolist()
        offsets = [tuple(x) for x in enc["offset_mapping"][0].tolist()]
        tokens = self.tokenizer.convert_ids_to_tokens(ids)
        valid = [i for i, (tid, am) in enumerate(zip(ids, attn_mask))
                 if am == 1 and (not self.exclude_special_tokens or tid not in self._special_ids)]
        return TokenizedExample(
            example_id=example.example_id, domain=example.domain, text=example.text,
            tokens=tokens, token_ids=ids, attention_mask=attn_mask,
            offset_mapping=offsets, valid_token_indices=valid, model_name=self.name,
        )

    @torch.no_grad()
    def extract(self, example: Example) -> AttentionArtifact:
        tokenized = self.tokenize_example(example)
        inputs = self.tokenizer(
            example.text, return_tensors="pt", truncation=True,
            max_length=self.max_length, padding=False, add_special_tokens=True,
        )
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        outputs = self.model(**inputs, output_attentions=True)
        if outputs.attentions is None:
            raise RuntimeError(f"Model {self.hf_id} did not return attentions.")
        attn = np.stack([a[0].detach().float().cpu().numpy() for a in outputs.attentions])
        nl, nh, seq, _ = attn.shape
        return AttentionArtifact(
            example_id=example.example_id, domain=example.domain, model_name=self.name,
            tokens=tokenized.tokens, token_ids=tokenized.token_ids,
            attention=attn, valid_token_indices=tokenized.valid_token_indices,
            causal=self.causal, seq_len=seq, num_layers=nl, num_heads=nh,
        )
