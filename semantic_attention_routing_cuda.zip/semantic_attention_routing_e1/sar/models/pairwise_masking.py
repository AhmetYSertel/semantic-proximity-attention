"""Pairwise attention masking utilities.

This module provides runtime masking utilities for encoder (BERT/RoBERTa) and
decoder (GPT-2) models.

Goal: Apply a *pairwise* keep-mask (seq x seq) derived from semantic proximity
without having to modify HF source code on disk.

Notes:
- Encoder models generally accept 4D additive attention masks.
- GPT-2 does not natively accept pairwise masks. We monkeypatch GPT2Attention
  modules by wrapping their private `_attn` method.

The patch is conservative: if something looks unsupported, callers should
fallback to full attention.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Tuple

import torch


@dataclass
class PairwiseMask:
    """Binary keep mask."""

    keep: torch.Tensor  # bool [bsz, seq, seq]


def pairwise_to_additive_mask(
    keep: torch.Tensor,
    *,
    dtype: torch.dtype,
    device: torch.device,
    neg_inf: Optional[float] = None,
) -> torch.Tensor:
    """Convert boolean keep mask [bsz, seq, seq] to additive mask [bsz, 1, seq, seq].

    Values:
      0 for keep, -inf for masked.

    `neg_inf` defaults to the minimum finite value for the dtype.
    """

    if keep.dtype != torch.bool:
        raise TypeError(f"keep mask must be bool, got {keep.dtype}")

    if keep.dim() != 3:
        raise ValueError(f"keep mask must be [bsz, seq, seq], got shape {tuple(keep.shape)}")

    # ensure mask and additive live on the same device
    keep = keep.to(device=device, dtype=torch.bool, non_blocking=True)

    if neg_inf is None:
        # large negative for the dtype
        if dtype in (torch.float16, torch.bfloat16):
            neg_inf = -1e4
        else:
            neg_inf = -1e9

    additive = torch.zeros((keep.size(0), 1, keep.size(1), keep.size(2)), dtype=dtype, device=device)
    additive = additive.masked_fill(~keep.unsqueeze(1), neg_inf)
    return additive


def apply_pairwise_mask_gpt2(
    model: torch.nn.Module,
    mask_provider: Callable[[int], torch.Tensor],
) -> Callable[[], None]:
    """Monkeypatch GPT-2 attention modules to apply a pairwise mask.

    Parameters
    ----------
    model:
        A GPT-2 family model (AutoModelForCausalLM / GPT2LMHeadModel).

    mask_provider:
        A callable taking `batch_index` and returning boolean keep mask
        of shape [seq, seq] for that item.

        The mask must already include causal constraints.

    Returns
    -------
    unpatch:
        A callable that restores original methods.

    Implementation detail
    ---------------------
    We wrap each attention module's `_attn` method.

    WARNING: This relies on HF internals; it may break across versions.
    """

    # Import locally so the module doesn't hard-depend on GPT2 classes.
    try:
        from transformers.models.gpt2.modeling_gpt2 import GPT2Attention  # type: ignore
    except Exception as e:  # pragma: no cover
        raise RuntimeError("transformers GPT-2 attention class not available") from e

    originals: list[Tuple[GPT2Attention, Callable]] = []

    def _wrap(attn: GPT2Attention):
        # Two implementation paths exist across transformers versions:
        # (A) older eager attention exposes a private `_attn` method (we can wrap it)
        # (B) newer implementations may not expose `_attn` (e.g., SDPA/FlashAttention paths);
        #     in that case we wrap `forward` and *add* an extra 4D additive mask.
        if hasattr(attn, "_attn"):
            orig = attn._attn  # type: ignore[attr-defined]

            def patched_attn(query, key, value, attention_mask=None, head_mask=None):
                # orig returns (attn_output, attn_weights)
                if query.dim() != 4:
                    return orig(query, key, value, attention_mask=attention_mask, head_mask=head_mask)

                bsz = query.size(0)
                q_len = query.size(-2)
                k_len = key.size(-2)

                if q_len != k_len:
                    # kv-cache / incremental decoding: out-of-scope
                    return orig(query, key, value, attention_mask=attention_mask, head_mask=head_mask)

                device = query.device
                dtype = query.dtype

                keep = torch.stack([mask_provider(i).to(device=device) for i in range(bsz)], dim=0)
                if keep.shape != (bsz, q_len, k_len):
                    return orig(query, key, value, attention_mask=attention_mask, head_mask=head_mask)

                add = pairwise_to_additive_mask(keep, dtype=dtype, device=device)

                if attention_mask is None:
                    attention_mask2 = add
                else:
                    attention_mask2 = attention_mask + add

                return orig(query, key, value, attention_mask=attention_mask2, head_mask=head_mask)

            attn._attn = patched_attn  # type: ignore[attr-defined]
            originals.append((attn, orig))
            return

        # Fallback path: patch `forward`
        orig_fwd = attn.forward

        def patched_forward(*args, **kwargs):
            # Try to locate hidden_states and attention_mask in kwargs / args.
            # GPT2Attention.forward signature varies; we avoid strict positional assumptions.
            attention_mask = kwargs.get("attention_mask", None)
            # hidden_states is always first positional arg after `self`
            hidden_states = args[0] if len(args) > 0 else kwargs.get("hidden_states", None)

            if hidden_states is None or not torch.is_tensor(hidden_states):
                return orig_fwd(*args, **kwargs)

            bsz = hidden_states.size(0)
            q_len = hidden_states.size(1)

            # We can only safely add a pairwise mask if the attention_mask is already 4D additive
            # broadcastable to [bsz, heads, q, k]. If not, fall back.
            if attention_mask is not None and torch.is_tensor(attention_mask) and attention_mask.dim() == 4:
                device = hidden_states.device
                dtype = hidden_states.dtype
                keep = torch.stack([mask_provider(i).to(device=device) for i in range(bsz)], dim=0)
                if keep.shape == (bsz, q_len, q_len):
                    add = pairwise_to_additive_mask(keep, dtype=dtype, device=device)
                    kwargs["attention_mask"] = attention_mask + add
                    return orig_fwd(*args, **kwargs)

            # If attention_mask is None, some HF versions build causal mask internally and still
            # accept a 4D attn_mask later (e.g. SDPA). We only attempt this when no mask exists.
            if attention_mask is None:
                device = hidden_states.device
                dtype = hidden_states.dtype
                keep = torch.stack([mask_provider(i).to(device=device) for i in range(bsz)], dim=0)
                if keep.shape == (bsz, q_len, q_len):
                    add = pairwise_to_additive_mask(keep, dtype=dtype, device=device)
                    kwargs["attention_mask"] = add
                    return orig_fwd(*args, **kwargs)

            return orig_fwd(*args, **kwargs)

        attn.forward = patched_forward  # type: ignore[assignment]
        originals.append((attn, orig_fwd))


    for module in model.modules():
        if module.__class__.__name__ == "GPT2Attention":
            _wrap(module)  # type: ignore

    def unpatch():
        for attn, orig in originals:
            if hasattr(attn, "_attn"):
                attn._attn = orig  # type: ignore[attr-defined]
            else:
                attn.forward = orig  # type: ignore[assignment]

    return unpatch
