from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
from sar.utils.io import read_yaml

@dataclass
class InputConfig:
    dataset_jsonl: str
    max_examples: Optional[int] = None

@dataclass
class SaveConfig:
    example_level_json: bool = True
    aggregate_csv: bool = True

@dataclass
class MetricsConfig:
    auc_top_quantile: float = 0.10
    kendall_exact_max_pairs: int = 300
    kendall_sample_size: int = 10000

@dataclass
class AggregationConfig:
    include_per_head: bool = False
    include_layer_mean: bool = True
    include_model_mean: bool = True

@dataclass
class FilterConfig:
    exclude_self_pairs: bool = True
    exclude_special_tokens: bool = True
    causal_valid_only: bool = True

@dataclass
class SentenceEncoderConfig:
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    normalize_embeddings: bool = True
    # Keep sentence-transformers on CPU by default to avoid GPU contention.
    # Set to "cuda" (or "cuda:0") if you prefer speed over memory.
    device: str = "cpu"

@dataclass
class SP2Config:
    window_k: int = 5
    normalize_embeddings: bool = True

@dataclass
class SP3Config:
    spacy_model: str = "en_core_web_sm"
    sentence_fallback: bool = True
    use_trf_ablation_only: bool = True

@dataclass
class ModelConfig:
    name: str; hf_id: str; family: str
    causal: bool = False; max_length: int = 512; exclude_special_tokens: bool = True

@dataclass
class E1Config:
    seed: int = 42; device: str = "cpu"; output_dir: str = "results/e1"; batch_size: int = 1
    input: InputConfig = field(default_factory=lambda: InputConfig(dataset_jsonl="data/examples.jsonl"))
    save: SaveConfig = field(default_factory=SaveConfig)
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    aggregation: AggregationConfig = field(default_factory=AggregationConfig)
    filters: FilterConfig = field(default_factory=FilterConfig)
    sentence_encoder: SentenceEncoderConfig = field(default_factory=SentenceEncoderConfig)
    sp2: SP2Config = field(default_factory=SP2Config)
    sp3: SP3Config = field(default_factory=SP3Config)
    models: List[ModelConfig] = field(default_factory=list)
    sp_types: List[str] = field(default_factory=lambda: ["sp1_raw_token"])
    controls: List[str] = field(default_factory=lambda: ["random","positional_distance","lexical_overlap","frequency_baseline"])

def _merge(base: Dict, override: Dict) -> Dict:
    m = dict(base)
    for k, v in override.items():
        m[k] = _merge(m[k], v) if isinstance(v, dict) and isinstance(m.get(k), dict) else v
    return m

def _find_root(start: Path, max_up=6) -> Path:
    cur = start.resolve()
    if cur.is_file(): cur = cur.parent
    for _ in range(max_up + 1):
        if (cur / "configs").exists(): return cur
        if cur.parent == cur: break
        cur = cur.parent
    raise FileNotFoundError(f"Cannot find project root from {start}")

def load_e1_config(experiment_yaml, global_yaml=None) -> E1Config:
    exp_path = Path(experiment_yaml).resolve()
    root = _find_root(exp_path)
    configs_dir = root / "configs"
    gpath = Path(global_yaml) if global_yaml else configs_dir / "global.yaml"
    merged = _merge(read_yaml(gpath), read_yaml(exp_path))

    model_entries = merged.get("models", [])
    if model_entries and all(isinstance(x, str) for x in model_entries):
        loaded = []
        for name in model_entries:
            p = configs_dir / "models" / f"{name}.yaml"
            if not p.exists(): raise FileNotFoundError(p)
            loaded.append(read_yaml(p))
        model_entries = loaded

    sp_types = merged.get("sp_types", [])
    if "sp1_raw_token" in sp_types:
        sp1 = configs_dir / "sp" / "sp1_raw_token.yaml"
        if sp1.exists():
            merged["sentence_encoder"] = _merge(read_yaml(sp1), merged.get("sentence_encoder", {}))
    if "sp2_windowed_span" in sp_types:
        sp2 = configs_dir / "sp" / "sp2_windowed.yaml"
        if sp2.exists():
            merged["sp2"] = _merge(read_yaml(sp2), merged.get("sp2", {}))

    return E1Config(
        seed=int(merged.get("seed", 42)),
        device=str(merged.get("device", "cpu")),
        output_dir=str(merged.get("output_dir", "results/e1")),
        batch_size=int(merged.get("batch_size", 1)),
        input=InputConfig(**merged["input"]),
        save=SaveConfig(**merged.get("save", {})),
        metrics=MetricsConfig(**merged.get("metrics", {})),
        aggregation=AggregationConfig(**merged.get("aggregation", {})),
        filters=FilterConfig(**merged.get("filters", {})),
        sentence_encoder=SentenceEncoderConfig(**merged.get("sentence_encoder", {})),
        sp2=SP2Config(**merged.get("sp2", {})),
        sp3=SP3Config(**merged.get("sp3", {})),
        models=[ModelConfig(**m) for m in model_entries],
        sp_types=list(sp_types),
        controls=list(merged.get("controls", ["random","positional_distance","lexical_overlap","frequency_baseline"])),
    )
