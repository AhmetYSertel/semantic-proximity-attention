"""One-command benchmark runner.

Usage (Colab/local):
  python run_all.py --mode smoke --device cuda

Modes:
  smoke: tiny runs to validate environment & plumbing.
  full:  full E1/E2 run (can be expensive).

This script intentionally uses subprocess to mirror real CLI usage.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


def run(cmd: list[str], cwd: str | None = None) -> None:
    """Run a subprocess with project root on PYTHONPATH."""
    env = os.environ.copy()
    root = str(Path(__file__).resolve().parent)
    env["PYTHONPATH"] = root + (os.pathsep + env["PYTHONPATH"] if "PYTHONPATH" in env else "")
    print("\n>>>", " ".join(cmd), flush=True)
    subprocess.check_call(cmd, cwd=cwd, env=env)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["smoke", "full"], default="smoke")
    ap.add_argument("--device", default=None, help="Override device in configs (cuda/cpu).")
    ap.add_argument("--e3_limit", type=int, default=200, help="Limit for E3 scripts (paper-grade: 200).")
    args = ap.parse_args()

    root = Path(__file__).resolve().parent
    os.chdir(root)

    python = sys.executable

    # Prefer module execution for import safety.
    # Note: sample_datasets.py lives under scripts/.

    if args.mode == "smoke":
        e1_cfg = "configs/experiments/e1_smoke_test.yaml"
    else:
        e1_cfg = "configs/experiments/e1_correlation.yaml"

    # In full mode, ensure domain_samples.jsonl exists by running the sampler.
    if args.mode == "full":
        # Read the expected dataset path from the config file in a lightweight way.
        # We avoid importing sar.config here to keep this runner minimal.
        cfg_path = root / e1_cfg
        dataset_path = None
        try:
            import yaml  # type: ignore

            data = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
            dataset_path = data.get("input", {}).get("dataset_jsonl")
        except Exception:
            dataset_path = None

        if dataset_path:
            ds = root / dataset_path
            if not ds.exists():
                sampler = root / "scripts" / "sample_datasets.py"
                if sampler.exists():
                    run([python, "-m", "scripts.sample_datasets", "--config", e1_cfg], cwd=str(root))
                else:
                    raise RuntimeError("scripts/sample_datasets.py not found; cannot build domain_samples.jsonl")

    # Optionally patch device by exporting ENV that config loader reads.
    # The current pipeline reads device from yaml; simplest override is to
    # rely on yaml editing by user. We keep CLI override for E3 only.

    # 0) Smoke E1
    run([python, "-m", "scripts.run_e1_correlation", "--config", e1_cfg], cwd=str(root))

    # 1) E2 (if available)
    e2_script = root / "scripts" / "run_e2_threshold.py"
    if e2_script.exists():
        run([python, "-m", "scripts.run_e2_threshold", "--config", e1_cfg, "--target_mass", "0.80"], cwd=str(root))
    else:
        print("(skip) scripts/run_e2_threshold.py not found")

    # 1b) Make plots from E1 results
    plots_script = root / "scripts" / "make_plots.py"
    if plots_script.exists():
        run([python, "-m", "scripts.make_plots", "--results_dir", "results/e1"], cwd=str(root))
    else:
        print("(skip) scripts/make_plots.py not found")

    # 2) E3 Encoder
    e3e = root / "scripts" / "run_e3_downstream_encoder.py"
    if e3e.exists():
        run([python, "-m", "scripts.run_e3_downstream_encoder", "--config", "configs/experiments/e3_encoder_sst2.yaml", "--limit", str(args.e3_limit)], cwd=str(root))
    else:
        print("(skip) E3 encoder script not found")

    # 3) E3 Decoder
    e3d = root / "scripts" / "run_e3_downstream_decoder.py"
    if e3d.exists():
        run([python, "-m", "scripts.run_e3_downstream_decoder", "--config", "configs/experiments/e3_decoder_wikitext2.yaml", "--limit", str(args.e3_limit)], cwd=str(root))
    else:
        print("(skip) E3 decoder script not found")

    print("\nAll done.")


if __name__ == "__main__":
    main()
