# Semantic Attention Routing (SAR) — Experiment Pipeline

**Core idea:** Use semantic proximity (computed via a sentence-transformer) as an attention
prior. The project tests whether attention weights in pretrained transformers correlate with
semantic similarity, and whether similarity-based masking can retain attention mass (and
downstream quality) while reducing pairwise comparisons.

## Pipeline Stages

- **E1 — Correlation Analysis:** Extract attention matrices and compare them to multiple
  similarity definitions (SP1 token-only, SP2 windowed-span) plus negative controls; report
  Spearman/Kendall and separability AUC.
- **E2 — Threshold Sweep:** Sweep similarity thresholds (quantiles) and measure tradeoff
  between retained pair fraction vs retained attention mass; report Coverage Efficiency Score (CES).
- **E3 — Downstream Feasibility:** Apply a similarity-derived sparse pairwise mask and
  measure downstream effect. Encoder E3 uses SST-2 accuracy; Decoder E3 uses WikiText-2
  language modeling NLL/PPL.

## File Map

| Area | Key files |
|------|-----------|
| Configs | `configs/global.yaml`; `configs/experiments/e1_correlation.yaml`; `e1_smoke_test.yaml`; `e3_encoder_sst2.yaml`; `e3_decoder_wikitext2.yaml` |
| Data | `scripts/sample_datasets.py` creates `data/domain_samples.jsonl`; `data/examples.jsonl` used for smoke tests |
| E1 | `scripts/run_e1_correlation.py`; `sar/models/attention_extractor.py`; `sar/semantics/sp1_raw_token.py`; `sp2_windowed_span.py`; `sar/metrics/correlation.py`; `sar/semantics/controls.py` |
| E2 | `scripts/run_e2_threshold.py` (threshold sweep and break-even summary) |
| E3 | `scripts/run_e3_downstream_encoder.py`; `scripts/run_e3_downstream_decoder.py`; `sar/models/pairwise_masking.py` (pairwise mask injection + GPT-2 compatibility) |
| Utilities | `sar/config.py` (YAML merge + dataclasses); `sar/utils/io.py` (JSONL loader); `seeds.py`/`device.py` |

## Install

```bash
pip install -r requirements.txt
```

## Reproducible Runs

### Cache and Rate Limits

For cloud runs, set a HF token to avoid rate limiting; keep cache paths stable so models
are not repeatedly downloaded or materialized:

```bash
export HF_TOKEN=...  # optional but recommended
export HF_HOME=/content/hf
export TRANSFORMERS_CACHE=/content/hf/transformers
export HF_DATASETS_CACHE=/content/hf/datasets
export SENTENCE_TRANSFORMERS_HOME=/content/hf/sentence_transformers
```

### One-command full run (paper-grade)

```bash
python run_all.py --mode full --e3_limit 200
```

### Manual step-by-step (debug friendly)

```bash
python -m scripts.sample_datasets --config configs/experiments/e1_correlation.yaml
python -m scripts.run_e1_correlation --config configs/experiments/e1_correlation.yaml
python -m scripts.run_e2_threshold --config configs/experiments/e1_correlation.yaml --target_mass 0.80
python -m scripts.make_plots --results_dir results/e1

# optional E3
python -m scripts.run_e3_downstream_encoder --config configs/experiments/e3_encoder_sst2.yaml --limit 200
python -m scripts.run_e3_downstream_decoder --config configs/experiments/e3_decoder_wikitext2.yaml --limit 200
```

### Smoke test (plumbing check)

```bash
python run_all.py --mode smoke
```

## Key Output Artifacts

| Stage | Primary outputs (relative paths) |
|-------|----------------------------------|
| E1 | `results/e1/aggregates/correlation_summary.csv`; `results/e1/aggregates/gating_decision.json`; `results/e1/plots/*` |
| E2 | `results/e2/aggregates/threshold_sweep.csv`; `results/e2/aggregates/break_even_summary.json` |
| E3 encoder | `results/e3_encoder/e3_encoder_summary.yaml` |
| E3 decoder | `results/e3_decoder/e3_decoder_summary.yaml` |

## Results Interpretation

### E1: What to look for

Main comparison: `positional_distance` vs `SP2_windowed_span`. Positional distance typically
dominates, but SP2 shows a strong secondary signal. SP1 is usually weak. The intended framing
is **Weak SAR**: semantic proximity is an informative prior even if it does not fully explain attention.

Typical aggregate pattern (sanity-check reference):

| Similarity type | Typical mean Spearman ρ |
|----------------|-------------------------|
| positional_distance | ~0.54 |
| sp2_windowed_span | ~0.47 |
| sp1_raw_token | ~0.11 |
| random | ~0.00 |

### E2: What to look for

CES (Coverage Efficiency Score) = retained_mass / retained_pair_fraction. CES > 1 means the
mask retains more attention mass than random selection. SP2 showed CES ~2 at extreme quantiles
(e.g., q=0.98).

### E3: What to look for

Encoder E3: compare `acc_full` vs `acc_sar`; expectation is small or zero delta for conservative
masks. Decoder E3 is harder: naive global quantile masking can catastrophically increase NLL if
the mask violates causal constraints or starves queries. A robust decoder baseline usually needs
per-query budget (top-k) plus local window and strict causal masking.

## Debug History and Applied Fixes

| Topic | Resolution |
|-------|------------|
| Import/path issues | Use module execution (`python -m scripts....`) and ensure PYTHONPATH includes repo root. `run_all.py` enforces this. |
| HF datasets breaking change | `daily_dialog` replaced with parquet-friendly alternatives (persona-chat, wikimedia/wikipedia, squad; github-code via streaming). |
| Performance: O(n²) Python loops | Pair masks and control computations vectorized; smoke tests keep sequence lengths small. |
| Token cleaning | SP2 span reconstruction cleans `##`, `Ġ`, `▁` prefixes. |
| Schema mismatches | `TokenizedExample`/`AttentionArtifact`/`SimilarityArtifact` fields aligned across modules. |
| GPU/CPU mismatch | `pairwise_to_additive_mask` moves keep mask to target device before `masked_fill`. |
| GPT-2 compatibility | Older patches assumed `GPT2Attention._attn` exists; pairwise masking made version-aware by wrapping `forward` when `_attn` is absent. |
| Repeated sentence-transformer loads | `SentenceTransformer` model loading cached/singleton via `sar/semantics/model_cache.py`. |

## Suggested Next Steps

- Add SP3 (clause-anchored) proximity and compare against SP2.
- Add head/layer specialization analysis (E8) to locate where semantic priors are strongest.
- Compute partial correlation / regression to quantify SP2 signal after controlling for positional distance.
- Decoder E3: implement per-query top-k + local window masking and report NLL delta vs sparsity.
- Scale the full run: 200 examples per domain and 128/256/512 buckets; produce publication-ready figures.

## Dataset Format

```json
{"example_id": "dialogue_0001", "domain": "dialogue", "text": "Hello there. How are you?"}
{"example_id": "code_0001", "domain": "code", "text": "def add(a, b):\n    return a + b"}
```
